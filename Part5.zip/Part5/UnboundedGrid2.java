

import java.util.ArrayList;

/**
 * A <code>BoundedGrid</code> is a rectangular grid with a finite number of
 * rows and columns. <br />
 * The implementation of this class is testable on the AP CS AB exam.
 */
import java.util.ArrayList;
import java.util.LinkedList;

import com.sun.glass.ui.Size;
import com.sun.rowset.internal.Row;

import info.gridworld.grid.AbstractGrid;
import info.gridworld.grid.Location;

/**
 * A <code>SparseBoundedGrid</code> is a rectangular grid with a finite number of
 * rows and columns. <br />
 * The implementation of this class is testable on the AP CS AB exam.
 */

public class UnboundedGrid2<E> extends AbstractGrid<E>  {

	
	private int size;
	private Object[][] map;
	
	public UnboundedGrid2() {
		
		size = 16;
		map = new Object[size][size];
		
	}
	@Override
	public int getNumRows() {
		// unbound
		return -1;
	}

	@Override
	public int getNumCols() {
		// unbound
		return -1;
	}

	@Override
	public boolean isValid(Location loc) {
		// TODO Auto-generated method stub
		if(loc.getRow() < 0 || loc.getCol() < 0) {
		return false;
		}
		return true;
	}

	@Override
	public E put(Location loc, E obj) {
		if(!isValid(loc)) {
			return null;
		}
		int r = loc.getRow();
		int c = loc.getCol();
		if(size < r || size < c) {
			//resize
			int max = r > c ? r : c;
			int newsize = max * 2;
			Object[][] newmap = new Object[newsize][newsize];
			for(int i = 0;i < size;i++) {
				for(int j = 0;j < size;j++) {
					newmap[i][j] = map[i][j];
				}
			}
			size = newsize;
			map = newmap;
			
		}
		E res = get(loc);
		map[r][c] = obj;
		return res;
	}

	@Override
	public E remove(Location loc) {
		// TODO Auto-generated method stub
		if(!isValid(loc)) {
			return null;
		}
		int r = loc.getRow();
		int c = loc.getCol();
		E res = get(loc);
		map[r][c] = null;
		return res;
	}

	@Override
	public E get(Location loc) {
		// TODO Auto-generated method stub
		if(!isValid(loc)) {
			return null;
		}
		int r = loc.getRow();
		int c = loc.getCol();
		if(size <= r || size <= c) {
			return null;
		}
		return (E)map[r][c];
	}

	@Override
	public ArrayList<Location> getOccupiedLocations() {
		// TODO Auto-generated method stub
		ArrayList<Location> res = new ArrayList<Location>();
		
		for(int i = 0;i < size;i++) {
			for(int j = 0;j < size;j++) {
				Location temp = new Location(i,j);
				if(get(temp) == null) {
					continue;
				}else {
					res.add(temp);
				}
			}
		}
		
		return res;
	}

}

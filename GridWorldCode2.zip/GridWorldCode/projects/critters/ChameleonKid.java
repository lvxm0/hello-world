/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Chris Nevison
 * @author Barbara Cloud Wells
 * @author Cay Horstmann
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;

import java.awt.Color;
import java.util.ArrayList;

/**
 * A <code>ChameleonCritter</code> takes on the color of neighboring actors as
 * it moves through the grid. <br />
 * The implementation of this class is testable on the AP CS A and AB exams.
 */
public class  ChameleonKid extends Critter
{
    
	/**
     * changes its color to the color of one of the actors immediately in front or behind
     */
	private float GREYDEGREE = 0.75f;
    public void processActors(ArrayList<Actor> actors)
    {
       /* int n = actors.size();
        if (n == 0) {
        	Color before = getColor();
        	Color later = new Color((int)(before.getRed()*GREYDEGREE), (int)(before.getGreen()*GREYDEGREE), (int)(before.getBlue()*GREYDEGREE));
        	setColor(later);
        	return;
        }
        int r = (int) (Math.random());
        */
        int direction = getDirection();
    	Location location = getLocation();
    	//front
    	Location temp = location.getAdjacentLocation(direction);
    	Actor front = null,back = null;
    	if(getGrid().isValid(temp)) {
    		front = getGrid().get(temp);
    	}
    	temp = location.getAdjacentLocation(direction + 180);
    	if(getGrid().isValid(temp)) {
    		back = getGrid().get(temp);
    	}
    	if(front != null) {
    		setColor(front.getColor());
    		return;
    	}
    	if(back != null) {
    		setColor(back.getColor());
    		return;
    	}else {
    		Color before = getColor();
        	Color later = new Color((int)(before.getRed()*GREYDEGREE), (int)(before.getGreen()*GREYDEGREE), (int)(before.getBlue()*GREYDEGREE));
        	setColor(later);
        	return;
    	}
    	
    }

    /**
     * Turns towards the new location as it moves.
     */
    public void makeMove(Location loc)
    {
        setDirection(getLocation().getDirectionToward(loc));
        super.makeMove(loc);
    }
}

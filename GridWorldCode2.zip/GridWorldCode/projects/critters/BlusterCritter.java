/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Chris Nevison
 * @author Barbara Cloud Wells
 * @author Cay Horstmann
 */

import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

import java.awt.Color;
import java.io.Console;
import java.util.ArrayList;

/**
 * A <code>ChameleonCritter</code> takes on the color of neighboring actors as
 * it moves through the grid. <br />
 * The implementation of this class is testable on the AP CS A and AB exams.
 */
public class BlusterCritter  extends Critter
{
	private int c = 0;
//	private static final float light = 1.25f;
    private static final float dark = 0.75f;
	public BlusterCritter(int number) {
		c = number;
	}
	
	/**
     * all of the neighbors within two steps of its current location. 
     * (For a BlusterCritter not near an edge, this includes 24 locations)
     */
    public ArrayList<Actor> getActors()
    {
        
    	ArrayList<Actor> actors = new ArrayList<Actor>();
    	Grid<Actor> gr = getGrid();
    	//24 unit side 
    	int xl, xh, yl, yh;
    	//get grid size
        int row = gr.getNumRows()-1, col = gr.getNumCols()-1;
        Location location = getLocation();
        
        xl = location.getRow() - 2;
        xh = location.getRow() + 2;
        yl = location.getCol() - 2;
        yh = location.getCol() + 2;
        // correct
       
        xl = xl < 0 ? 0 : xl;
        xh = xh > row ? row : xh;
        yl = yl < 0 ? 0 : yl;
        yh = yh > col ? col : yh;
        //*/
        //add
      //  System.out.println(xl +"," + xh);
      //  System.out.println(yl +"," + yh);
        for(int i = xl;i <= xh;i++ ) {
        	for(int j = yl;j<= yh;j++) {
        	//	System.out.println("normal" + i +"," + j);
        		if(i == location.getRow() && j == location.getCol()) {
        			continue;
        		}
        		Location temp = new Location(i, j);
        		if(gr.isValid(temp)) {
        			Actor actor = gr.get(temp);
	        		if(actor != null) {
	  //      			System.out.println("success" + i +"," + j);
	        			actors.add(actor);
	        		}
        		}
        	}
        }
        return actors;
       // */
    	//return getGrid().getNeighbors(getLocation());
        
    }
    /**
     *  If there are fewer than c critters, 
     *  the BlusterCritter��s color gets brighter (color values increase). 
     *  If there are c or more critters, the BlusterCritter��s color dark (color values decrease)
     */
    public void processActors(ArrayList<Actor> actors)
    {
    	
        if(c > actors.size()) {
        	Color before = getColor();
        	int r = before.getRed();
        	int g = before.getGreen();
        	int b = before.getBlue();
        	if(r == 0 && g ==0 && b ==0) {
        		r = 10;
        		g = 10;
        		b = 10;
        	}
        	r = (int)(r*(1+dark));
        	g = (int)(g*(1+dark));
        	b = (int)(b*(1+dark));
        	System.out.println(r + " " +g +" "+b);
        	r = r > 255 ? 255 : r;
        	g = g > 255 ? 255 : g;
        	b = b > 255 ? 255 : b; 
        	Color later = new Color(r, g, b);
        	System.out.println(r + " " +g +" "+b);
        	setColor(later);
        	return;
        	
        }else {
        	Color before = getColor();
        	int r = (int)(before.getRed()*(1-dark));
        	int g = (int)(before.getGreen()*(1-dark));
        	int b = (int)(before.getBlue()*(1-dark));
        	r = r < 0 ? 0 : r;
        	g = g < 0 ? 0 : g;
        	b = b < 0 ? 0 : b; 
        	Color later = new Color(r, g, b);
        	setColor(later);
        	return;
        }
        
    }

}

package info.gridworld.grid;
/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2002-2006 College Entrance Examination Board 
 * (http://www.collegeboard.com).
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Alyce Brady
 * @author APCS Development Committee
 * @author Cay Horstmann
 */


import java.util.ArrayList;
import java.util.LinkedList;

import info.gridworld.grid.AbstractGrid;
import info.gridworld.grid.Location;

/**
 * A <code>SparseBoundedGrid</code> is a rectangular grid with a finite number of
 * rows and columns. <br />
 * The implementation of this class is testable on the AP CS AB exam.
 */
public class SparseBoundedGrid<E> extends AbstractGrid<E> {

	//field
	private SparseGridNode[] array;
	private int row;
	private int col;
	
	public SparseBoundedGrid(int r,int c) {
		row = r > 0 ? r : 0;
		col = c > 0 ? c : 0;
		if(row > 0) {
		array = new SparseGridNode[row];
		}
	}
	@Override
	public int getNumRows() {
		// TODO Auto-generated method stub
		return row;
	}

	@Override
	public int getNumCols() {
		// TODO Auto-generated method stub
		return col;
	}

	@Override
	public boolean isValid(Location loc) {
		if(loc.getRow() < 0 || loc.getRow() >= row) {
			return false;
		}
		if(loc.getCol() < 0 || loc.getCol() >= col) {
			return false;
		}
		return true;
	}

	@Override
	public E put(Location loc, E obj) {
		// TODO Auto-generated method stub
		if(obj == null) {
			 throw new NullPointerException("obj == null");
		}
		if(!isValid(loc)) {
			throw new IllegalArgumentException("Location " + loc + " is not valid");
		}
		//put front
		SparseGridNode temp = array[loc.getRow()];
		E res = (E)temp.getOccupant();
		SparseGridNode newnode = new SparseGridNode(obj,loc.getCol(),null,temp);
		if(temp != null) {
			temp.setPre(newnode);
		}
		array[loc.getRow()] = newnode;
		return res;
		
	}

	@Override
	public E remove(Location loc) {
		// TODO Auto-generated method stub
		if(isValid(loc)) {
			SparseGridNode temp = getNode(loc);
			if(temp != null) {
				//record
				E remv = (E)temp.getOccupant();
				
				SparseGridNode front = temp.getPre();
				SparseGridNode back = temp.getNext();
				if(front!=null) {
					front.setNext(back);
				}
				else {
					array[loc.getRow()] = back;
				}
				if(back != null) {
					back.setPre(front);
				}
				temp = null;
				return remv;
			}
			return null;
		}
		return null;
	}

	@Override
	public E get(Location loc) {
		// TODO Auto-generated method stub
		if(isValid(loc)) {
			SparseGridNode temp = getNode(loc);
			if(temp != null) {
				return (E)temp.getOccupant();
			}
			return null;
		}
		return null;
	}

	@Override
	public ArrayList<Location> getOccupiedLocations() {
		// TODO Auto-generated method stub
		ArrayList<Location> res = new ArrayList<Location>();
		for(int i = 0;i < row;i++) {
			SparseGridNode temp = array[i];
			while(temp != null) {
				Location newloc = new Location(i, temp.getCol());
				res.add(newloc);
				temp = temp.getNext();
			}
		}
		
		return res;
	}
	//assist
	private SparseGridNode getNode(Location loc) {
		int r = loc.getRow();
		int c = loc.getCol();
		SparseGridNode head = array[r];
		SparseGridNode temp = head;
		while(temp != null && temp.getCol() != c) {
			temp = temp.getNext();
		}
		return temp;
	}
	
	
}

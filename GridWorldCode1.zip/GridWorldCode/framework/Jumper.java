/* 
 * AP(r) Computer Science GridWorld Case Study:
 * Copyright(c) 2005-2006 Cay S. Horstmann (http://horstmann.com)
 *
 * This code is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * @author Cay Horstmann
 * @author Chris Nevison
 * @author Barbara Cloud Wells
 */
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Flower;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Critter;

import java.awt.Color;
import java.time.Instant;
import java.util.PrimitiveIterator.OfDouble;

import info.gridworld.actor.Bug;

/**
 * A <code>BoxBug</code> traces out a square "box" of a given size. <br />
 * The implementation of this class is testable on the AP CS A and AB exams.
 */
public class Jumper extends Bug
{

    /**
     * Constructs a box bug that traces a square of a given side length
     * @param length the side length
     */
	public Location nextloc;
    public Jumper()
    {
    	setColor(Color.orange);
    	setDirection(90);
    }
    public Jumper(Color color )
    {
        setColor(color);
        setDirection(90);
    }

    /**
     * jump two step; can't jump,move;can't move, turn, until can move
     */
    public void act()
    {
        if(canJump()) {
        	
        	jump(nextloc);
        }
        else if(canMove()) {
        	move();
        }
        else {
        	turn();
        }
    }
    public boolean canJump() {

    	Grid<Actor> grid = getGrid();
    	
    	int direction = getDirection();
    	Location location = getLocation();
    	//get next direction step1 and judge
    	Location temp = location.getAdjacentLocation(direction);
    	if(grid.isValid(temp) == false) {
    		return false;
    	}
    	//get next direction step2 and judge
    	temp = temp.getAdjacentLocation(direction);
    	if(grid.isValid(temp) == false) {
    		return false;
    	}
    	Actor judge = grid.get(temp);
    	
    	if(judge == null) {
    		nextloc = temp;
    		return true;
    	}
    	else if(judge instanceof Flower ) {
    		nextloc = temp;
    		return true;
    	}
    	else {
    		return false;    		
    	}

    }
    public boolean canMove() {
    	Grid<Actor> grid = getGrid();
    	
    	int direction = getDirection();
    	Location location = getLocation();
    	//get next direction step1 and judge
    	Location temp = location.getAdjacentLocation(direction);
    	if(grid.isValid(temp) == false) {
    		return false;
    	}
    	Actor judge = grid.get(temp);
    	
    	if(judge == null) {
    		return true;
    	}
    	else if(judge instanceof Flower ) {
    		return true;
    	}
    	else {
    		return false;    		
    	}
    }
    public void jump(Location next) {
    	 Grid<Actor> gr = getGrid();
         if (gr == null)
             return;
         //Location loc = getLocation();
        // Location next = loc.getAdjacentLocation(getDirection());
         if (gr.isValid(next))
             moveTo(next);
         else
             removeSelfFromGrid();
    }
    public void turn() {
    	setDirection(getDirection() + Location.HALF_RIGHT);
    }
    public void move() {
    	//same to bug.java
    	 Grid<Actor> gr = getGrid();
         if (gr == null)
             return;
         Location loc = getLocation();
         Location next = loc.getAdjacentLocation(getDirection());
         if (gr.isValid(next))
             moveTo(next);
         else
             removeSelfFromGrid();
         Flower flower = new Flower(getColor());
         flower.putSelfInGrid(gr, loc);
    }
}

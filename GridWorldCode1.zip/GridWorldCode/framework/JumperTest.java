import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;
import info.gridworld.world.World;

public class JumperTest {
	
	ActorWorld world = new ActorWorld();
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testAct() {
		//jump
		Jumper fir = new Jumper(Color.red);
		world.add(new Location(3, 3),fir);
		fir.act();
		Location temp = fir.getLocation();
		assertEquals(3, temp.getRow());
		assertEquals(5, temp.getCol());
		
		//jump meet a rock->move
		Rock rock = new Rock();
		world.add(new Location(3, 7),rock);
		fir.act();
		temp = fir.getLocation();
		assertEquals(3, temp.getRow());
		assertEquals(6, temp.getCol());
		
		//neighbor is rock
		//Rock rock2 = new Rock();
		//world.add(new Location(4, 6),rock);
		fir.act();
		temp = fir.getLocation();
		assertEquals(3, temp.getRow());
		assertEquals(8, temp.getCol());
		
		//jump is the wall->move
		fir.act();
		temp = fir.getLocation();
		assertEquals(3, temp.getRow());
		assertEquals(9, temp.getCol());
		
		//can't move ->turn
		fir.act();
		int dir = fir.getDirection();
		assertEquals(135, dir);
		fir.act();
		dir = fir.getDirection();
		assertEquals(180, dir);
		
		//normal jump
		fir.act();
		temp = fir.getLocation();
		assertEquals(5, temp.getRow());
		assertEquals(9, temp.getCol());
		
	}

}
